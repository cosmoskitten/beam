import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
logging.debug("test")

with open('abc.txt', 'w+') as f:
    for n in range(1,2):
        f.write(str(n))

import subprocess
subprocess.call(['gsutil', 'cp', 'abc.txt', 'gs://ningk-test/'])

import apache_beam as beam
import apache_beam.transforms.window as window
from apache_beam.runners.interactive import interactive_runner
from apache_beam.options.pipeline_options import PipelineOptions

pipeline_options = PipelineOptions()
p = beam.Pipeline(interactive_runner.InteractiveRunner(), options =
                  pipeline_options)

txt = p | "ReadFromFile" >> beam.io.ReadFromText('./abc.txt')

txt | "WriteToFile" >> beam.io.WriteToText('./efg.txt')


result = p.run()
result.wait_until_finish()

