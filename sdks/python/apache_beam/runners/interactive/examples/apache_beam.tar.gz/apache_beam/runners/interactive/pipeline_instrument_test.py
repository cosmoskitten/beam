#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""Tests for apache_beam.runners.interactive.pipeline_instrument."""

import tempfile
import unittest

import apache_beam as beam
from apache_beam.runners.direct import direct_runner
from apache_beam.runners.interactive import cache_manager as cache
from apache_beam.runners.interactive import interactive_beam as ibeam
from apache_beam.runners.interactive import pipeline_instrument as instr


class PipelineInstrumentTest(unittest.TestCase):

  def setUp(self):
    ibeam.new_env(cache_manager=cache.FileBasedCacheManager())
    ibeam.current_env().watch(self)

  def assertPipelineEqual(self, actual_pipeline, expected_pipeline):
    actual_pipeline_proto = actual_pipeline.to_runner_api(use_fake_coders=True)
    expected_pipeline_proto = expected_pipeline.to_runner_api(
        use_fake_coders=True)
    components1 = actual_pipeline_proto.components
    components2 = expected_pipeline_proto.components

    self.assertEqual(len(components1.transforms), len(components2.transforms))
    self.assertEqual(len(components1.pcollections),
                     len(components2.pcollections))

    # GreatEqual instead of Equal because the pipeline_proto_to_execute could
    # include more windowing_stratagies and coders than necessary.
    self.assertGreaterEqual(len(components1.windowing_strategies),
                            len(components2.windowing_strategies))
    self.assertGreaterEqual(len(components1.coders), len(components2.coders))
    self.assertTransformEqual(actual_pipeline_proto,
                              actual_pipeline_proto.root_transform_ids[0],
                              expected_pipeline_proto,
                              expected_pipeline_proto.root_transform_ids[0])

  def assertTransformEqual(self, actual_pipeline_proto, actual_transform_id,
      expected_pipeline_proto, expected_transform_id):
    transform_proto1 = actual_pipeline_proto.components.transforms[
      actual_transform_id]
    transform_proto2 = expected_pipeline_proto.components.transforms[
      expected_transform_id]
    self.assertEqual(transform_proto1.spec.urn, transform_proto2.spec.urn)
    # Skipping payload checking because PTransforms of the same functionality
    # could generate different payloads.
    self.assertEqual(len(transform_proto1.subtransforms),
                     len(transform_proto2.subtransforms))
    self.assertSetEqual(set(transform_proto1.inputs),
                        set(transform_proto2.inputs))
    self.assertSetEqual(set(transform_proto1.outputs),
                        set(transform_proto2.outputs))

  def test_pcolls_to_pcoll_id(self):
    p = ibeam.create_pipeline()
    init_pcoll = p | 'Init Create' >> beam.Create(range(10))
    _, ctx = p.to_runner_api(use_fake_coders=True, return_context=True)
    self.assertEqual(instr.pcolls_to_pcoll_id(p, ctx), {
        str(init_pcoll): 'ref_PCollection_PCollection_1'})

  def test_cacheable_key_without_version_map(self):
    p = ibeam.create_pipeline()
    init_pcoll = p | 'Init Create' >> beam.Create(range(10))
    _, ctx = p.to_runner_api(use_fake_coders=True, return_context=True)
    self.assertEqual(
        instr.cacheable_key(init_pcoll, instr.pcolls_to_pcoll_id(p, ctx)),
        ','.join((str(id(init_pcoll)), 'ref_PCollection_PCollection_1')))

  def test_cacheable_key_with_version_map(self):
    p = ibeam.create_pipeline()
    init_pcoll = p | 'Init Create' >> beam.Create(range(10))

    # It's normal that when executing, the pipeline object is a different
    # instance from what user has built but the pipeline graph is exactly
    # the same. The pipeline instrument should be able to identify if the
    # original instance has changed in an interactive env while mutating
    # the other instance for execution. The version map can be used to figure
    # out what the PCollection instances are in the original instance and if
    # the evaluation has changed since last execution.
    p2 = beam.Pipeline(runner=direct_runner.DirectRunner())
    init_pcoll_2 = p2 | 'Init Create' >> beam.Create(range(10))
    _, ctx = p2.to_runner_api(use_fake_coders=True, return_context=True)

    # The cacheable_key should use id(init_pcoll) as prefix even when
    # init_pcoll_2 is supplied as long as the version map is given.
    self.assertEqual(
        instr.cacheable_key(init_pcoll_2, instr.pcolls_to_pcoll_id(p2, ctx), {
            'ref_PCollection_PCollection_1': str(id(init_pcoll))}),
        ','.join((str(id(init_pcoll)), 'ref_PCollection_PCollection_1')))

  def test_cacheables(self):
    p = ibeam.create_pipeline()
    init_pcoll = p | 'Init Create' >> beam.Create(range(10))
    squares = init_pcoll | 'Square' >> beam.Map(lambda x: x * x)
    cubes = init_pcoll | 'Cube' >> beam.Map(lambda x: x ** 3)

    # Watch the local variables, i.e., the Beam pipeline defined.
    ibeam.watch(locals())

    pin = instr.pin(p)
    self.assertEqual(pin.cacheables(), {
        pin._cacheable_key(init_pcoll): {
            'var': 'init_pcoll',
            'version': str(id(init_pcoll)),
            'pcoll_id': 'ref_PCollection_PCollection_1',
            'pcoll': init_pcoll
        },
        pin._cacheable_key(squares): {
            'var': 'squares',
            'version': str(id(squares)),
            'pcoll_id': 'ref_PCollection_PCollection_2',
            'pcoll': squares
        },
        pin._cacheable_key(cubes): {
            'var': 'cubes',
            'version': str(id(cubes)),
            'pcoll_id': 'ref_PCollection_PCollection_3',
            'pcoll': cubes
        }
    })

  def test_has_unbounded_source(self):
    p = ibeam.create_pipeline()
    p | 'ReadUnboundedSource' >> beam.io.ReadFromPubSub(
        subscription='projects/fake-project/subscriptions/fake_sub')
    self.assertTrue(instr.has_unbounded_source(p))

  def test_not_has_unbounded_source(self):
    p = ibeam.create_pipeline()
    with tempfile.NamedTemporaryFile(delete=False) as f:
      f.write(b'test')
    p | 'ReadBoundedSource' >> beam.io.ReadFromText(f.name)
    self.assertFalse(instr.has_unbounded_source(p))


if __name__ == '__main__':
  unittest.main()
