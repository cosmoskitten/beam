#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

"""A runner that allows running of Beam pipelines interactively.

This module is experimental. No backwards-compatibility guarantees.
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import logging

import apache_beam as beam
from apache_beam import runners
from apache_beam.runners.direct import direct_runner
from apache_beam.runners.interactive import cache_manager as cache
from apache_beam.runners.interactive import interactive_beam as ibeam
from apache_beam.runners.interactive import pipeline_analyzer
from apache_beam.runners.interactive import pipeline_instrument as inst
from apache_beam.runners.interactive.display import display_manager
from apache_beam.runners.interactive.display import pipeline_graph_renderer

# size of PCollection samples cached.
SAMPLE_SIZE = 8


class InteractiveRunner(runners.PipelineRunner):
  """An interactive runner for Beam Python pipelines.

  Allows interactively building and running Beam Python pipelines.
  """

  def __init__(self,
      underlying_runner=None,
      cache_dir=None,
      cache_format='text',
      render_option=None):
    """Constructor of InteractiveRunner.

    Args:
      underlying_runner: (runner.PipelineRunner)
      cache_dir: (str) the directory where PCollection caches are kept
      cache_format: (str) the file format that should be used for saving
          PCollection caches. Available options are 'text' and 'tfrecord'.
      render_option: (str) this parameter decides how the pipeline graph is
          rendered. See display.pipeline_graph_renderer for available options.
    """
    self._underlying_runner = (underlying_runner
                               or direct_runner.DirectRunner())
    self._cache_manager = cache.FileBasedCacheManager(cache_dir, cache_format)
    ibeam.current_env().set_cache_manager(self._cache_manager)
    self._renderer = pipeline_graph_renderer.get_renderer(render_option)
    self._in_session = False

  def set_render_option(self, render_option):
    """Sets the rendering option.

    Args:
      render_option: (str) this parameter decides how the pipeline graph is
          rendered. See display.pipeline_graph_renderer for available options.
    """
    self._renderer = pipeline_graph_renderer.get_renderer(render_option)

  def start_session(self):
    """Start the session that keeps back-end managers and workers alive.
    """
    if self._in_session:
      return

    enter = getattr(self._underlying_runner, '__enter__', None)
    if enter is not None:
      logging.info('Starting session.')
      self._in_session = True
      enter()
    else:
      logging.error('Keep alive not supported.')

  def end_session(self):
    """End the session that keeps backend managers and workers alive.
    """
    if not self._in_session:
      return

    exit = getattr(self._underlying_runner, '__exit__', None)
    if exit is not None:
      self._in_session = False
      logging.info('Ending session.')
      exit(None, None, None)

  def cleanup(self):
    self._cache_manager.cleanup()

  def apply(self, transform, pvalueish, options):
    # TODO(qinyeli, BEAM-646): Remove runner interception of apply.
    return self._underlying_runner.apply(transform, pvalueish, options)

  def run_pipeline(self, pipeline, options):
    # The pipeline here is already a copy of original pipeline instance defined
    # by user code. Pipeline instrument will use/mutate this instance together
    # with metadata from the original pipeline. Pipeline instrument also holds
    # a snapshot of this instance in case a recover is needed elsewhere.
    pin = inst.pin(pipeline, options)

    # analyzer = pipeline_analyzer.PipelineAnalyzer(pin,
    #                                               self._underlying_runner,
    #                                               options,
    #                                               [])
    #
    # display = display_manager.DisplayManager(
    #     pipeline_proto=pin.original_pipeline_proto(),
    #     pipeline_analyzer=analyzer,
    #     cache_manager=pin.cache_manager(),
    #     pipeline_graph_renderer=self._renderer)
    # if pin.has_unbounded_source():
    #   display.push_notice('Streaming is not yet fully supported! E.g.,'
    #                       ' unbounded PCollection might not be introspectable.')
    # display.start_periodic_update()
    # Builds a pipeline object to be executed with underlying runner.
    pipeline_to_execute = beam.pipeline.Pipeline.from_runner_api(
        pin.instrumented_pipeline_proto(),
        self._underlying_runner,
        options)
    result = pipeline_to_execute.run()
    result.wait_until_finish()
    # display.stop_periodic_update()

    return PipelineResult(result, pin)


class PipelineResult(beam.runners.runner.PipelineResult):
  """Provides access to information about a pipeline."""

  def __init__(self, underlying_result, pin):
    super(PipelineResult, self).__init__(underlying_result.state)
    self._pin = pin

  def wait_until_finish(self):
    # PipelineResult is not constructed until pipeline execution is finished.
    return

  def get(self, pcoll):
    logging.warning(self._pin.cache_manager()._cache_dir)
    key = self._pin.cache_key(pcoll)
    logging.warning('get key %s', key)
    if self._pin.cache_manager().exists('full', key):
      pcoll_list, _ = self._pin.cache_manager().read('full', key)
      return pcoll_list
    else:
      raise ValueError('PCollection not available, please run the pipeline.')
